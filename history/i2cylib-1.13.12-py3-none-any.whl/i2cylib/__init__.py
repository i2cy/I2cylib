#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author: i2cy(i2cy@outlook.com)
# Filename: __init__.py
# Created on: 2021/3/6

from .utils import *
from .crypto import *
from .filesystem import *
from .network import *
from .database import *
from .engineering import *
from .serial import *
from .hid import *

__VERSION__ = '1.13.12'
name = "i2cylib"
description = "This is a universal package contains a lot of useful functions and tools written by I2cy."
