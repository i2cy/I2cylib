#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author: i2cy(i2cy@outlook.com)
# Filename: __init__.py
# Created on: 2021/3/6

from .icfat import *
