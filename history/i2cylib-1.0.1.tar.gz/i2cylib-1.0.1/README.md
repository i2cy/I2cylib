# 主要包含
 - `ICCode` i2cy常用的混淆算法
 - `Dynkey` 动态验证密匙生成/验证工具
 - `SQLiteDB` SQLite3数据库面向对象式API
 - `ICFat64` 类FAT虚拟文件系统
 - `I2TCP_protocol` 一般的用户层通讯协议
 - `utils` 各种常用的小工具